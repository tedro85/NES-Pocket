# NES Pocket

NES Pocket is a small Android NES-only emulator project.

## v0.2.0 ZIP ROM support

This build supports both:

- Raw `.nes` ROM files
- `.zip` archives that contain one or more `.nes` ROM files

ZIP ROMs are extracted into the app's private storage before the Nestopia core is started. This prevents compressed ZIP bytes from being passed to the emulator core as though they were a raw NES cartridge image.

The startup scanner checks shared storage for both `.nes` files and `.zip` archives. ZIP archives are inspected for NES ROM entries and valid ROMs are cached privately for launch. The manual picker also accepts either `.nes` or `.zip`.

ROMs are validated for the standard iNES header (`NES` + `0x1A`) before launch so invalid/compressed files fail with a message instead of being passed to the native core.

## Controls

- On-screen D-pad, A, B, Start, Select
- Edit mode for dragging controls
- Resize and opacity controls
- Add/remove controls
- Saved control layout
- Hardware controller input

## Saves

- Battery-backed SRAM
- Save state / load state

## Build

The app uses LibretroDroid 0.14.0 as the Android frontend and the GPL Nestopia libretro core for NES emulation. The Gradle build downloads the arm64-v8a Nestopia core from the official libretro buildbot and bundles it in the APK.

Run:

```bash
gradle assembleDebug
```

The debug APK is produced at:

`app/build/outputs/apk/debug/app-debug.apk`

No commercial ROMs are included in this project.
