# NES Pocket 0.3.0

NES-only Android emulator prototype.

## What changed in 0.3.0

- Keeps the NES core extracted as a real native library file and passes an absolute path to LibretroDroid.
- Packages both ARM64 (real phones) and x86_64 (GitHub virtual Android test phone) cores.
- Uses conservative default shader/audio settings while stability is being proven.
- Shows LibretroDroid load errors in-app instead of silently returning to the launcher when possible.
- Adds an Android instrumentation smoke test that generates a tiny legal NES ROM, launches it, and requires an actual rendered frame.
- The GitHub workflow is intended to upload an APK only after that virtual Android smoke test passes.

The app accepts raw `.nes` files and `.zip` archives containing `.nes` files. No commercial ROMs are included.

## CI virtual Android smoke test
When `gradle assembleDebug` runs in GitHub Actions, version 0.4 automatically boots an Android 15 x86_64 emulator, installs the APK, launches a generated mapper-2/UxROM NES test cartridge, and requires LibretroDroid/Nestopia to render a frame. A failed smoke test fails the Gradle build, so the existing GitHub workflow will not publish an APK that cannot boot the NES core in CI.
