# NES Pocket

A focused Android NES emulator front-end for personal ROM files.

## What this build includes

- NES only (`.nes` files)
- Automatic device scan every time the library screen resumes
- Detects new ROMs and refreshes/removes stale entries
- Manual ROM picker fallback
- Full-screen landscape emulation
- Movable on-screen controls
- Add/remove any NES button manually
- Tap a control in edit mode to resize it or change opacity
- Control positions persist between launches
- Hardware/Bluetooth/USB controller forwarding
- Battery-backed SRAM persistence
- One quick save-state slot per ROM
- Reset game and reset control-layout options

## Emulator engine

The app uses LibretroDroid 0.13.2 as the Android frontend and the Nestopia libretro core for NES emulation. The Gradle build downloads the arm64-v8a Nestopia core from the official libretro buildbot and bundles it in the APK.

No commercial ROMs are included.

## Android storage behavior

Modern Android restricts full-device file scanning. For automatic scanning, the app asks the user to grant **All files access** in Android settings. Without that permission, the user can still tap **Choose ROM** and import a `.nes` file through Android's system file picker.

The scanner intentionally skips `Android/data` and `Android/obb`, which Android protects even when broad storage access is granted.

## Build

### Android Studio

1. Open this folder in current Android Studio.
2. Let Gradle sync.
3. Build **app** / Debug APK.
4. The build downloads the Nestopia core automatically.

### Command line

Requires Android SDK + JDK 17 + Gradle 8.7:

```bash
gradle assembleDebug
```

APK output:

`app/build/outputs/apk/debug/app-debug.apk`

## GitHub Actions

The included `.github/workflows/build-apk.yml` builds a debug APK on every push to `main` or when manually dispatched, and publishes the APK as a workflow artifact.

## License note

LibretroDroid is GPL-3.0 and Nestopia is GPL-2.0-or-later. Keep their applicable license notices and source obligations if distributing a compiled build.
