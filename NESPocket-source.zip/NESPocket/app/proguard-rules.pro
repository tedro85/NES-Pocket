# NES Pocket - no custom shrinking rules yet.
