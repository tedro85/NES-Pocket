import java.net.URI
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nespocket.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nespocket.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 4
        versionName = "0.4.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // ARM64 is used by the real phone; x86_64 is used by the CI Android emulator.
        ndk {
            abiFilters += listOf("arm64-v8a", "x86_64")
        }
    }

    sourceSets["main"].jniLibs.srcDir(layout.buildDirectory.dir("generated/jniLibs"))

    packaging {
        jniLibs {
            // Libretro loads the emulator core with dlopen(), so keep the core as a real
            // extracted file in nativeLibraryDir instead of only inside the APK zip.
            useLegacyPackaging = true
            keepDebugSymbols.add("**/libnestopia_libretro_android.so")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("com.github.Swordfish90:LibretroDroid:0.14.0")

    androidTestImplementation("androidx.test:core-ktx:1.6.1")
    androidTestImplementation("androidx.test:runner:1.6.2")
    androidTestImplementation("androidx.test:rules:1.6.1")
    androidTestImplementation("androidx.test.ext:junit-ktx:1.2.1")
}

val coreAbis = listOf("arm64-v8a", "x86_64")

val prepareNestopiaCores by tasks.registering {
    val outFiles = coreAbis.map { abi ->
        layout.buildDirectory.file("generated/jniLibs/$abi/libnestopia_libretro_android.so")
    }
    outputs.files(outFiles)

    doLast {
        coreAbis.forEachIndexed { index, abi ->
            val target = outFiles[index].get().asFile
            if (target.exists() && target.length() > 0) return@forEachIndexed

            target.parentFile.mkdirs()
            val zipFile = layout.buildDirectory.file("downloads/nestopia_$abi.zip").get().asFile
            zipFile.parentFile.mkdirs()

            val url = URI(
                "https://buildbot.libretro.com/nightly/android/latest/$abi/" +
                    "nestopia_libretro_android.so.zip"
            ).toURL()

            logger.lifecycle("Downloading GPL Nestopia NES core for $abi from libretro buildbot...")
            url.openStream().use { input ->
                zipFile.outputStream().use { output -> input.copyTo(output) }
            }

            var found = false
            ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
                var entry = zip.nextEntry
                while (entry != null) {
                    if (!entry.isDirectory && entry.name.endsWith("nestopia_libretro_android.so")) {
                        target.outputStream().use { output -> zip.copyTo(output) }
                        found = true
                        break
                    }
                    entry = zip.nextEntry
                }
            }
            check(found) { "Nestopia core for $abi was not found inside downloaded archive." }
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(prepareNestopiaCores)
}


// On GitHub Actions, the existing `gradle assembleDebug` workflow also boots a
// headless Android 15 x86_64 device and performs a real emulator smoke test.
// This keeps the user's phone out of the debug loop: a build only succeeds if
// the app installs and the NES core renders a frame.
val ciAndroidSmokeTest by tasks.registering(Exec::class) {
    group = "verification"
    description = "Boots a CI Android device and verifies NES emulation renders a frame."
    onlyIf { System.getenv("GITHUB_ACTIONS") == "true" }
    workingDir(rootProject.projectDir)
    commandLine("bash", rootProject.file("ci/android-smoke-test.sh").absolutePath)
}

tasks.matching { it.name == "assembleDebug" }.configureEach {
    finalizedBy(ciAndroidSmokeTest)
}
