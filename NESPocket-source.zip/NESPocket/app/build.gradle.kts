import java.net.URI
import java.util.zip.ZipInputStream

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nespocket.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nespocket.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 2
        versionName = "0.2.0"

        ndk {
            abiFilters += listOf("arm64-v8a")
        }
    }

    sourceSets["main"].jniLibs.srcDir(layout.buildDirectory.dir("generated/jniLibs"))

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.3")
    implementation("com.github.Swordfish90:LibretroDroid:0.14.0")
}

val prepareNestopiaCore by tasks.registering {
    val outDir = layout.buildDirectory.dir("generated/jniLibs/arm64-v8a")
    val outFile = outDir.map { it.file("libnestopia_libretro_android.so") }
    outputs.file(outFile)

    doLast {
        val target = outFile.get().asFile
        if (target.exists() && target.length() > 0) return@doLast

        target.parentFile.mkdirs()
        val zipFile = layout.buildDirectory.file("downloads/nestopia_arm64.zip").get().asFile
        zipFile.parentFile.mkdirs()

        val url = URI(
            "https://buildbot.libretro.com/nightly/android/latest/arm64-v8a/" +
                "nestopia_libretro_android.so.zip"
        ).toURL()

        logger.lifecycle("Downloading GPL Nestopia NES core from libretro buildbot...")
        url.openStream().use { input ->
            zipFile.outputStream().use { output -> input.copyTo(output) }
        }

        var found = false
        ZipInputStream(zipFile.inputStream().buffered()).use { zip ->
            var entry = zip.nextEntry
            while (entry != null) {
                if (!entry.isDirectory && entry.name.endsWith("nestopia_libretro_android.so")) {
                    target.outputStream().use { output -> zip.copyTo(output) }
                    found = true
                    break
                }
                entry = zip.nextEntry
            }
        }
        check(found) { "Nestopia core was not found inside downloaded archive." }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn(prepareNestopiaCore)
}
