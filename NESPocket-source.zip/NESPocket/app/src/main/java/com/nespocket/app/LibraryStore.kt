package com.nespocket.app

import android.content.Context
import java.io.File

class LibraryStore(context: Context) {
    private val prefs = context.getSharedPreferences("rom_library", Context.MODE_PRIVATE)

    fun loadPaths(): Set<String> = prefs.getStringSet(KEY_PATHS, emptySet())?.toSet() ?: emptySet()

    fun savePaths(paths: Collection<String>) {
        prefs.edit().putStringSet(KEY_PATHS, paths.toSet()).apply()
    }

    fun addPath(path: String) {
        val current = loadPaths().toMutableSet()
        current += path
        savePaths(current)
    }

    fun existingFiles(): List<File> = loadPaths()
        .asSequence()
        .map(::File)
        .filter { it.isFile && it.extension.equals("nes", ignoreCase = true) }
        .sortedBy { it.name.lowercase() }
        .toList()

    companion object {
        private const val KEY_PATHS = "paths"
    }
}
