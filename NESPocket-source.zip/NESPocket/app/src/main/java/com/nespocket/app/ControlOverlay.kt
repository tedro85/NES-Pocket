package com.nespocket.app

import android.app.AlertDialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import com.swordfish.libretrodroid.GLRetroView
import java.util.UUID
import kotlin.math.max
import kotlin.math.min

class ControlOverlay(
    context: Context,
    private val retroView: GLRetroView
) : FrameLayout(context) {

    private val store = ControlLayoutStore(context)
    private var specs = store.load()
    private val views = linkedMapOf<String, Button>()
    var editMode: Boolean = false
        private set

    init {
        clipChildren = false
        clipToPadding = false
        isMotionEventSplittingEnabled = true
        specs.forEach(::createControl)
    }

    fun setEditing(enabled: Boolean) {
        editMode = enabled
        views.forEach { (id, view) -> styleControl(view, specs.first { it.id == id }) }
        Toast.makeText(
            context,
            if (enabled) "Edit mode: drag buttons. Tap one to resize, fade, or remove." else "Control layout saved",
            Toast.LENGTH_LONG
        ).show()
        if (!enabled) saveLayout()
    }

    fun addControl(type: ControlType) {
        val spec = ControlSpec(
            id = UUID.randomUUID().toString(),
            type = type,
            xFraction = 0.45f,
            yFraction = 0.45f,
            sizeDp = if (type == ControlType.A || type == ControlType.B) 82 else 70,
            opacity = 0.62f
        )
        specs += spec
        createControl(spec)
        saveLayout()
        post { applyPosition(spec, views.getValue(spec.id)) }
    }

    fun resetLayout() {
        removeAllViews()
        views.clear()
        specs = store.reset()
        specs.forEach(::createControl)
        post { specs.forEach { applyPosition(it, views.getValue(it.id)) } }
    }

    fun saveLayout() = store.save(specs)

    private fun createControl(spec: ControlSpec) {
        val button = Button(context).apply {
            text = spec.type.label
            isAllCaps = false
            textSize = if (spec.type == ControlType.START || spec.type == ControlType.SELECT) 10f else 18f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 0)
            minWidth = 0
            minHeight = 0
            tag = spec.id
            setOnTouchListener(ControlTouchListener(spec))
        }
        views[spec.id] = button
        addView(button, LayoutParams(dp(spec.sizeDp), dp(spec.sizeDp)))
        styleControl(button, spec)
        post { applyPosition(spec, button) }
    }

    private fun styleControl(view: Button, spec: ControlSpec) {
        val fill = if (editMode) Color.rgb(70, 70, 90) else Color.rgb(35, 35, 40)
        view.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(fill)
            setStroke(dp(if (editMode) 3 else 1), if (editMode) Color.WHITE else Color.GRAY)
        }
        view.alpha = if (editMode) max(spec.opacity, 0.75f) else spec.opacity
    }

    private fun applyPosition(spec: ControlSpec, view: View) {
        if (width <= 0 || height <= 0) return
        view.x = (spec.xFraction * width).coerceIn(0f, max(0f, width - view.width.toFloat()))
        view.y = (spec.yFraction * height).coerceIn(0f, max(0f, height - view.height.toFloat()))
    }

    private fun updateSpecPosition(spec: ControlSpec, view: View) {
        if (width <= 0 || height <= 0) return
        spec.xFraction = (view.x / width).coerceIn(0f, 1f)
        spec.yFraction = (view.y / height).coerceIn(0f, 1f)
    }

    private fun showControlOptions(spec: ControlSpec) {
        val options = arrayOf("Bigger", "Smaller", "More visible", "More transparent", "Remove")
        AlertDialog.Builder(context)
            .setTitle("${spec.type.name} button")
            .setItems(options) { _, which ->
                when (which) {
                    0 -> spec.sizeDp = min(160, spec.sizeDp + 10)
                    1 -> spec.sizeDp = max(42, spec.sizeDp - 10)
                    2 -> spec.opacity = min(1f, spec.opacity + 0.1f)
                    3 -> spec.opacity = max(0.2f, spec.opacity - 0.1f)
                    4 -> {
                        views.remove(spec.id)?.let(::removeView)
                        specs.removeAll { it.id == spec.id }
                        saveLayout()
                        return@setItems
                    }
                }
                val view = views.getValue(spec.id)
                view.layoutParams = view.layoutParams.apply {
                    width = dp(spec.sizeDp)
                    height = dp(spec.sizeDp)
                }
                styleControl(view, spec)
                updateSpecPosition(spec, view)
                saveLayout()
            }
            .show()
    }

    private inner class ControlTouchListener(private val spec: ControlSpec) : OnTouchListener {
        private var downRawX = 0f
        private var downRawY = 0f
        private var startX = 0f
        private var startY = 0f
        private var gamePressed = false
        private var moved = false

        override fun onTouch(view: View, event: MotionEvent): Boolean {
            if (editMode) {
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downRawX = event.rawX
                        downRawY = event.rawY
                        startX = view.x
                        startY = view.y
                        moved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.rawX - downRawX
                        val dy = event.rawY - downRawY
                        if (kotlin.math.abs(dx) > dp(8) || kotlin.math.abs(dy) > dp(8)) moved = true
                        val maxX = max(0f, width - view.width.toFloat())
                        val maxY = max(0f, height - view.height.toFloat())
                        view.x = (startX + dx).coerceIn(0f, maxX)
                        view.y = (startY + dy).coerceIn(0f, maxY)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        updateSpecPosition(spec, view)
                        saveLayout()
                        if (!moved) showControlOptions(spec)
                        return true
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        updateSpecPosition(spec, view)
                        saveLayout()
                        return true
                    }
                }
                return true
            }

            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    retroView.sendKeyEvent(KeyEvent.ACTION_DOWN, spec.type.keyCode)
                    gamePressed = true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (gamePressed) retroView.sendKeyEvent(KeyEvent.ACTION_UP, spec.type.keyCode)
                    gamePressed = false
                }
            }
            return true
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
