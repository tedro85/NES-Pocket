package com.nespocket.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ControlLayoutStore(context: Context) {
    private val prefs = context.getSharedPreferences("control_layout", Context.MODE_PRIVATE)

    fun load(): MutableList<ControlSpec> {
        val raw = prefs.getString(KEY_LAYOUT, null) ?: return defaults()
        return runCatching {
            val array = JSONArray(raw)
            MutableList(array.length()) { index ->
                val o = array.getJSONObject(index)
                ControlSpec(
                    id = o.getString("id"),
                    type = ControlType.valueOf(o.getString("type")),
                    xFraction = o.getDouble("x").toFloat(),
                    yFraction = o.getDouble("y").toFloat(),
                    sizeDp = o.getInt("size"),
                    opacity = o.getDouble("opacity").toFloat()
                )
            }
        }.getOrElse { defaults() }
    }

    fun save(specs: Collection<ControlSpec>) {
        val array = JSONArray()
        specs.forEach { spec ->
            array.put(JSONObject().apply {
                put("id", spec.id)
                put("type", spec.type.name)
                put("x", spec.xFraction.toDouble())
                put("y", spec.yFraction.toDouble())
                put("size", spec.sizeDp)
                put("opacity", spec.opacity.toDouble())
            })
        }
        prefs.edit().putString(KEY_LAYOUT, array.toString()).apply()
    }

    fun reset(): MutableList<ControlSpec> {
        prefs.edit().remove(KEY_LAYOUT).apply()
        return defaults()
    }

    private fun defaults() = mutableListOf(
        spec(ControlType.UP, 0.14f, 0.58f, 70),
        spec(ControlType.LEFT, 0.07f, 0.72f, 70),
        spec(ControlType.RIGHT, 0.21f, 0.72f, 70),
        spec(ControlType.DOWN, 0.14f, 0.82f, 70),
        spec(ControlType.B, 0.73f, 0.72f, 82),
        spec(ControlType.A, 0.86f, 0.62f, 82),
        spec(ControlType.SELECT, 0.42f, 0.84f, 72),
        spec(ControlType.START, 0.53f, 0.84f, 72)
    )

    private fun spec(type: ControlType, x: Float, y: Float, size: Int) =
        ControlSpec(UUID.randomUUID().toString(), type, x, y, size, 0.62f)

    companion object {
        private const val KEY_LAYOUT = "layout_json"
    }
}
