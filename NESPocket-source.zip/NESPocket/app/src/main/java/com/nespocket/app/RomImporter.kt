package com.nespocket.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipInputStream

class RomImporter(private val context: Context) {
    data class Result(val files: List<File>, val error: String? = null)

    fun importUri(uri: Uri): Result {
        val name = queryDisplayName(uri) ?: "rom_${System.currentTimeMillis()}"
        return if (name.endsWith(".zip", ignoreCase = true)) {
            importZip(uri)
        } else {
            importNes(uri, name)
        }
    }

    private fun importNes(uri: Uri, displayName: String): Result {
        val dir = File(context.filesDir, "imported").apply { mkdirs() }
        val desired = if (displayName.endsWith(".nes", ignoreCase = true)) displayName else "$displayName.nes"
        val output = uniqueFile(dir, RomFileUtils.safeFileName(desired))

        val success = runCatching {
            context.contentResolver.openInputStream(uri)?.use { input ->
                output.outputStream().buffered().use { out -> input.copyTo(out) }
            } ?: error("Could not open selected file")
            require(RomFileUtils.isValidNes(output)) { "The selected file is not a valid NES ROM." }
        }.isSuccess

        return if (success) Result(listOf(output)) else {
            output.delete()
            Result(emptyList(), "That file is not a valid .nes ROM or NES ZIP.")
        }
    }

    private fun importZip(uri: Uri): Result {
        val dir = File(context.filesDir, "imported").apply { mkdirs() }
        val outputs = mutableListOf<File>()
        val result = runCatching {
            context.contentResolver.openInputStream(uri)?.buffered()?.use { raw ->
                ZipInputStream(raw).use { zip ->
                    var entry = zip.nextEntry
                    var count = 0
                    while (entry != null && count < MAX_ROMS_PER_ZIP) {
                        if (!entry.isDirectory && entry.name.endsWith(".nes", ignoreCase = true)) {
                            val output = uniqueFile(dir, RomFileUtils.safeFileName(entry.name))
                            FileOutputStream(output).buffered().use { out ->
                                copyLimited(zip, out, MAX_ROM_BYTES)
                            }
                            if (RomFileUtils.isValidNes(output)) {
                                outputs += output
                                count++
                            } else {
                                output.delete()
                            }
                        }
                        zip.closeEntry()
                        entry = zip.nextEntry
                    }
                }
            } ?: error("Could not open ZIP")
        }

        if (result.isFailure) outputs.forEach { it.delete() }
        return when {
            result.isFailure -> Result(emptyList(), "Could not read that ZIP archive.")
            outputs.isEmpty() -> Result(emptyList(), "That ZIP does not contain a valid .nes ROM.")
            else -> Result(outputs)
        }
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.getString(0) else null
        }
    }.getOrNull()

    private fun uniqueFile(dir: File, requestedName: String): File {
        val clean = if (requestedName.endsWith(".nes", ignoreCase = true)) requestedName else "$requestedName.nes"
        var candidate = File(dir, clean)
        if (!candidate.exists()) return candidate
        val base = candidate.nameWithoutExtension
        var index = 2
        while (candidate.exists()) {
            candidate = File(dir, "$base ($index).nes")
            index++
        }
        return candidate
    }

    private fun copyLimited(input: java.io.InputStream, output: java.io.OutputStream, maxBytes: Long) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { "NES file in ZIP is unexpectedly large" }
            output.write(buffer, 0, read)
        }
    }

    companion object {
        private const val MAX_ROMS_PER_ZIP = 20
        private const val MAX_ROM_BYTES = 32L * 1024L * 1024L
    }
}
