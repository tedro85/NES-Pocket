package com.nespocket.app

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.ViewportAlignment
import java.io.File
import java.security.MessageDigest

class EmulationActivity : AppCompatActivity() {
    private lateinit var retroView: GLRetroView
    private lateinit var controls: ControlOverlay
    private lateinit var romFile: File
    private lateinit var saveId: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemUi()

        val path = intent.getStringExtra(EXTRA_ROM_PATH)
        if (path.isNullOrBlank()) {
            finish()
            return
        }
        romFile = File(path)
        if (!romFile.isFile) {
            Toast.makeText(this, "ROM file is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        saveId = stableId(romFile.absolutePath)

        val savesDir = File(filesDir, "saves").apply { mkdirs() }
        val sramFile = File(savesDir, "$saveId.srm")

        val data = GLRetroViewData(this).apply {
            coreFilePath = "libnestopia_libretro_android.so"
            gameFilePath = romFile.absolutePath
            systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
            this.savesDirectory = savesDir.absolutePath
            variables = arrayOf()
            saveRAMState = if (sramFile.isFile) runCatching { sramFile.readBytes() }.getOrNull() else null
            shader = ShaderConfig.Sharp
            viewportAlignment = ViewportAlignment.CENTER
            rumbleEventsEnabled = false
            preferLowLatencyAudio = true
        }

        retroView = GLRetroView(this, data)
        lifecycle.addObserver(retroView)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isMotionEventSplittingEnabled = true
        }
        setContentView(root)

        root.addView(retroView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ).apply { gravity = Gravity.CENTER })

        controls = ControlOverlay(this, retroView)
        root.addView(controls, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        ))

        val menu = Button(this).apply {
            text = "☰"
            textSize = 18f
            alpha = 0.65f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(150, 20, 20, 20))
            setOnClickListener { showGameMenu() }
        }
        root.addView(menu, FrameLayout.LayoutParams(dp(58), dp(48)).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(10)
            rightMargin = dp(10)
        })
    }

    override fun onPause() {
        saveSram()
        controls.saveLayout()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            showGameMenu()
            return true
        }
        if (isControllerKey(keyCode)) {
            retroView.sendKeyEvent(KeyEvent.ACTION_DOWN, keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isControllerKey(keyCode)) {
            retroView.sendKeyEvent(KeyEvent.ACTION_UP, keyCode)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun isControllerKey(keyCode: Int): Boolean {
        return KeyEvent.isGamepadButton(keyCode) || keyCode in setOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER
        )
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        return retroView.onGenericMotionEvent(event) || super.onGenericMotionEvent(event)
    }

    private fun showGameMenu() {
        val editLabel = if (controls.editMode) "Finish editing controls" else "Edit controls"
        val items = arrayOf(
            editLabel,
            "Add on-screen button",
            "Reset control layout",
            "Save state",
            "Load state",
            "Reset game",
            "Exit game"
        )
        AlertDialog.Builder(this)
            .setTitle(romFile.nameWithoutExtension)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> controls.setEditing(!controls.editMode)
                    1 -> showAddControlDialog()
                    2 -> controls.resetLayout()
                    3 -> saveState()
                    4 -> loadState()
                    5 -> retroView.reset()
                    6 -> finish()
                }
            }
            .show()
    }

    private fun showAddControlDialog() {
        val types = ControlType.entries.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add button")
            .setItems(types.map { it.name }.toTypedArray()) { _, index ->
                controls.addControl(types[index])
                if (!controls.editMode) controls.setEditing(true)
            }
            .show()
    }

    private fun saveState() {
        val stateDir = File(filesDir, "states").apply { mkdirs() }
        val target = File(stateDir, "$saveId.state")
        runCatching { target.writeBytes(retroView.serializeState()) }
            .onSuccess { Toast.makeText(this, "State saved", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, "Could not save state", Toast.LENGTH_SHORT).show() }
    }

    private fun loadState() {
        val target = File(File(filesDir, "states"), "$saveId.state")
        if (!target.isFile) {
            Toast.makeText(this, "No saved state for this game yet", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching { retroView.unserializeState(target.readBytes()) }
            .onSuccess { ok ->
                Toast.makeText(this, if (ok) "State loaded" else "State rejected by core", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(this, "Could not load state", Toast.LENGTH_SHORT).show() }
    }

    private fun saveSram() {
        if (!::retroView.isInitialized) return
        val savesDir = File(filesDir, "saves").apply { mkdirs() }
        val target = File(savesDir, "$saveId.srm")
        runCatching {
            val data = retroView.serializeSRAM()
            if (data.isNotEmpty()) target.writeBytes(data)
        }
    }

    private fun hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }

    private fun stableId(value: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(20)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        const val EXTRA_ROM_PATH = "rom_path"
    }
}
