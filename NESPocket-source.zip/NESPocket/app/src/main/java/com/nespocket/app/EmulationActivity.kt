package com.nespocket.app

import android.content.pm.ActivityInfo
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.Button
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.ShaderConfig
import com.swordfish.libretrodroid.ViewportAlignment
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.io.File
import java.security.MessageDigest

class EmulationActivity : AppCompatActivity() {
    private lateinit var retroView: GLRetroView
    private lateinit var controls: ControlOverlay
    private lateinit var romFile: File
    private lateinit var saveId: String

    @Volatile
    var firstFrameRendered: Boolean = false
        private set

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemUi()

        val path = intent.getStringExtra(EXTRA_ROM_PATH)
        if (path.isNullOrBlank()) {
            finish()
            return
        }
        romFile = File(path)
        if (!romFile.isFile) {
            Toast.makeText(this, "ROM file is missing.", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        if (!RomFileUtils.isValidNes(romFile)) {
            Toast.makeText(
                this,
                "This file is not a valid NES ROM. ZIP files are extracted before launch.",
                Toast.LENGTH_LONG
            ).show()
            finish()
            return
        }
        saveId = stableId(romFile.absolutePath)

        // LibretroDroid calls dlopen() with this path. Using the absolute extracted native
        // library path avoids device-specific linker failures on newer Android versions.
        val coreFile = File(applicationInfo.nativeLibraryDir, CORE_LIBRARY_NAME)
        if (!coreFile.isFile) {
            showFatalError("NES emulator core is missing for this device (${android.os.Build.SUPPORTED_ABIS.joinToString()}).")
            return
        }

        val savesDir = File(filesDir, "saves").apply { mkdirs() }
        val sramFile = File(savesDir, "$saveId.srm")

        val data = GLRetroViewData(this).apply {
            coreFilePath = coreFile.absolutePath
            gameFilePath = romFile.absolutePath
            systemDirectory = File(filesDir, "system").apply { mkdirs() }.absolutePath
            this.savesDirectory = savesDir.absolutePath
            variables = arrayOf()
            saveRAMState = if (sramFile.isFile) runCatching { sramFile.readBytes() }.getOrNull() else null
            // Start with LibretroDroid's most conservative rendering/audio configuration.
            // Fancy shaders/low-latency audio can be re-enabled after stability testing.
            shader = ShaderConfig.Default
            viewportAlignment = ViewportAlignment.CENTER
            rumbleEventsEnabled = false
            preferLowLatencyAudio = false
        }

        retroView = GLRetroView(this, data)

        lifecycleScope.launch {
            retroView.getGLRetroErrors().collectLatest { errorCode ->
                Log.e(TAG, "LibretroDroid error code: $errorCode")
                showFatalError(libretroErrorMessage(errorCode))
            }
        }
        lifecycleScope.launch {
            retroView.getGLRetroEvents().collectLatest { event ->
                if (event is GLRetroView.GLRetroEvents.FrameRendered) {
                    if (!firstFrameRendered) {
                        firstFrameRendered = true
                        if (intent.getBooleanExtra(EXTRA_CI_SMOKE, false)) {
                            Log.i(TAG, "CI_SMOKE_OK first NES frame rendered")
                        }
                    }
                }
            }
        }

        lifecycle.addObserver(retroView)

        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            isMotionEventSplittingEnabled = true
        }
        setContentView(root)

        root.addView(
            retroView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            ).apply { gravity = Gravity.CENTER }
        )

        controls = ControlOverlay(this, retroView)
        root.addView(
            controls,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val menu = Button(this).apply {
            text = "☰"
            textSize = 18f
            alpha = 0.65f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.argb(150, 20, 20, 20))
            setOnClickListener { showGameMenu() }
        }
        root.addView(menu, FrameLayout.LayoutParams(dp(58), dp(48)).apply {
            gravity = Gravity.TOP or Gravity.END
            topMargin = dp(10)
            rightMargin = dp(10)
        })
    }

    override fun onPause() {
        saveSram()
        if (::controls.isInitialized) controls.saveLayout()
        super.onPause()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (::controls.isInitialized) showGameMenu() else finish()
            return true
        }
        if (::retroView.isInitialized && isControllerKey(keyCode)) {
            retroView.sendKeyEvent(KeyEvent.ACTION_DOWN, keyCode)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (::retroView.isInitialized && isControllerKey(keyCode)) {
            retroView.sendKeyEvent(KeyEvent.ACTION_UP, keyCode)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun isControllerKey(keyCode: Int): Boolean {
        return KeyEvent.isGamepadButton(keyCode) || keyCode in setOf(
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER
        )
    }

    override fun onGenericMotionEvent(event: MotionEvent): Boolean {
        return if (::retroView.isInitialized) {
            retroView.onGenericMotionEvent(event) || super.onGenericMotionEvent(event)
        } else {
            super.onGenericMotionEvent(event)
        }
    }

    private fun showGameMenu() {
        val editLabel = if (controls.editMode) "Finish editing controls" else "Edit controls"
        val items = arrayOf(
            editLabel,
            "Add on-screen button",
            "Reset control layout",
            "Save state",
            "Load state",
            "Reset game",
            "Exit game"
        )
        AlertDialog.Builder(this)
            .setTitle(romFile.nameWithoutExtension)
            .setItems(items) { _, which ->
                when (which) {
                    0 -> controls.setEditing(!controls.editMode)
                    1 -> showAddControlDialog()
                    2 -> controls.resetLayout()
                    3 -> saveState()
                    4 -> loadState()
                    5 -> retroView.reset()
                    6 -> finish()
                }
            }
            .show()
    }

    private fun showAddControlDialog() {
        val types = ControlType.entries.toTypedArray()
        AlertDialog.Builder(this)
            .setTitle("Add button")
            .setItems(types.map { it.name }.toTypedArray()) { _, index ->
                controls.addControl(types[index])
                if (!controls.editMode) controls.setEditing(true)
            }
            .show()
    }

    private fun saveState() {
        val stateDir = File(filesDir, "states").apply { mkdirs() }
        val target = File(stateDir, "$saveId.state")
        runCatching { target.writeBytes(retroView.serializeState()) }
            .onSuccess { Toast.makeText(this, "State saved", Toast.LENGTH_SHORT).show() }
            .onFailure { Toast.makeText(this, "Could not save state", Toast.LENGTH_SHORT).show() }
    }

    private fun loadState() {
        val target = File(File(filesDir, "states"), "$saveId.state")
        if (!target.isFile) {
            Toast.makeText(this, "No saved state for this game yet", Toast.LENGTH_SHORT).show()
            return
        }
        runCatching { retroView.unserializeState(target.readBytes()) }
            .onSuccess { ok ->
                Toast.makeText(this, if (ok) "State loaded" else "State rejected by core", Toast.LENGTH_SHORT).show()
            }
            .onFailure { Toast.makeText(this, "Could not load state", Toast.LENGTH_SHORT).show() }
    }

    private fun saveSram() {
        if (!::retroView.isInitialized) return
        val savesDir = File(filesDir, "saves").apply { mkdirs() }
        val target = File(savesDir, "$saveId.srm")
        runCatching {
            val data = retroView.serializeSRAM()
            if (data.isNotEmpty()) target.writeBytes(data)
        }
    }

    private fun showFatalError(message: String) {
        if (isFinishing || isDestroyed) return
        runOnUiThread {
            if (isFinishing || isDestroyed) return@runOnUiThread
            AlertDialog.Builder(this)
                .setTitle("Could not start NES game")
                .setMessage(message)
                .setCancelable(false)
                .setPositiveButton("Back") { _, _ -> finish() }
                .show()
        }
    }

    private fun libretroErrorMessage(code: Int): String = when (code) {
        GLRetroView.ERROR_LOAD_LIBRARY -> "The NES emulator core could not be loaded."
        GLRetroView.ERROR_LOAD_GAME -> "The NES emulator core rejected this ROM."
        GLRetroView.ERROR_GL_NOT_COMPATIBLE -> "This device's graphics configuration is not compatible with the emulator."
        GLRetroView.ERROR_SERIALIZATION -> "The emulator had a save-state error."
        else -> "The emulator stopped with error code $code."
    }

    private fun hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                )
        }
    }

    private fun stableId(value: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(20)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val TAG = "NESPocketEmulation"
        private const val CORE_LIBRARY_NAME = "libnestopia_libretro_android.so"
        const val EXTRA_ROM_PATH = "rom_path"
        const val EXTRA_CI_SMOKE = "ci_smoke"
    }
}
