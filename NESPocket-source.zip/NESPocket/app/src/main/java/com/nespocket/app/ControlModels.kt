package com.nespocket.app

import android.view.KeyEvent

enum class ControlType(val label: String, val keyCode: Int) {
    UP("▲", KeyEvent.KEYCODE_DPAD_UP),
    DOWN("▼", KeyEvent.KEYCODE_DPAD_DOWN),
    LEFT("◀", KeyEvent.KEYCODE_DPAD_LEFT),
    RIGHT("▶", KeyEvent.KEYCODE_DPAD_RIGHT),
    A("A", KeyEvent.KEYCODE_BUTTON_A),
    B("B", KeyEvent.KEYCODE_BUTTON_B),
    START("START", KeyEvent.KEYCODE_BUTTON_START),
    SELECT("SELECT", KeyEvent.KEYCODE_BUTTON_SELECT)
}

data class ControlSpec(
    val id: String,
    val type: ControlType,
    var xFraction: Float,
    var yFraction: Float,
    var sizeDp: Int,
    var opacity: Float
)
