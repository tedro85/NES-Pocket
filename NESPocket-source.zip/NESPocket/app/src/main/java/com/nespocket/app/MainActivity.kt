package com.nespocket.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.util.Log
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var libraryStore: LibraryStore
    private lateinit var status: TextView
    private lateinit var gamesContainer: LinearLayout
    private var permissionPromptShown = false

    private val readPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scanLibrary() else renderLibrary(libraryStore.existingFiles())
    }

    private val romPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPickedRom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        libraryStore = LibraryStore(this)
        if (intent.getBooleanExtra(EXTRA_CI_SMOKE, false)) {
            runCiSmokeTest()
            return
        }
        setContentView(buildUi())
        renderLibrary(libraryStore.existingFiles())
    }

    override fun onResume() {
        super.onResume()
        ensureScanPermissionAndScan()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(14, 14, 16)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        root.addView(TextView(this).apply {
            text = "NES Pocket"
            textSize = 30f
            setTextColor(Color.WHITE)
        })

        root.addView(TextView(this).apply {
            text = "NES-only emulator • scans .nes files and ZIPs containing .nes games"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(16))
        })

        status = TextView(this).apply {
            text = "Library ready"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(status)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START
        }
        actionRow.addView(Button(this).apply {
            text = "Rescan"
            setOnClickListener { ensureScanPermissionAndScan(forcePrompt = true) }
        })
        actionRow.addView(Button(this).apply {
            text = "Choose ROM / ZIP"
            setOnClickListener { romPicker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream", "*/*")) }
        })
        root.addView(actionRow)

        root.addView(TextView(this).apply {
            text = "Games"
            textSize = 21f
            setTextColor(Color.WHITE)
            setPadding(0, dp(20), 0, dp(8))
        })

        gamesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gamesContainer)
        return scroll
    }

    private fun ensureScanPermissionAndScan(forcePrompt: Boolean = false) {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> {
                if (Environment.isExternalStorageManager()) {
                    scanLibrary()
                } else if (forcePrompt || !permissionPromptShown) {
                    permissionPromptShown = true
                    showAllFilesPermissionDialog()
                }
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    scanLibrary()
                } else {
                    readPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
            else -> scanLibrary()
        }
    }

    private fun showAllFilesPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Allow ROM scanning")
            .setMessage("To find .nes files and ZIP archives containing NES ROMs anywhere in shared storage, NES Pocket needs Android's All files access. If you skip this, you can still use Choose ROM / ZIP.")
            .setPositiveButton("Open setting") { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                runCatching { startActivity(intent) }.onFailure {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
            .setNegativeButton("Not now") { _, _ -> renderLibrary(libraryStore.existingFiles()) }
            .show()
    }

    private fun scanLibrary() {
        status.text = "Scanning device for NES ROMs and ZIP archives…"
        executor.execute {
            val previous = libraryStore.loadPaths()
            val result = RomScanner(this).scan()
            val paths = result.files.map { it.absolutePath }.toSet()
            val newCount = (paths - previous).size
            libraryStore.savePaths(paths)
            runOnUiThread {
                status.text = "Found ${result.files.size} NES ROM(s) • $newCount new • checked ${result.zipArchives} ZIP(s)"
                renderLibrary(result.files)
            }
        }
    }

    private fun renderLibrary(files: List<File>) {
        gamesContainer.removeAllViews()
        if (files.isEmpty()) {
            gamesContainer.addView(TextView(this).apply {
                text = "No NES ROMs found yet. NES Pocket supports raw .nes files and .zip archives containing .nes files."
                setTextColor(Color.LTGRAY)
                textSize = 15f
                setPadding(0, dp(8), 0, dp(8))
            })
            return
        }

        files.forEach { file ->
            gamesContainer.addView(Button(this).apply {
                text = file.nameWithoutExtension
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { launchGame(file) }
            }, ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        }
    }

    private fun launchGame(file: File) {
        startActivity(Intent(this, EmulationActivity::class.java).apply {
            putExtra(EmulationActivity.EXTRA_ROM_PATH, file.absolutePath)
        })
    }

    private fun importPickedRom(uri: Uri) {
        status.text = "Importing ROM…"
        executor.execute {
            val result = RomImporter(this).importUri(uri)
            runOnUiThread {
                if (result.files.isNotEmpty()) {
                    val current = libraryStore.loadPaths().toMutableSet()
                    current += result.files.map { it.absolutePath }
                    libraryStore.savePaths(current)
                    status.text = if (result.files.size == 1) {
                        "Imported ${result.files.first().nameWithoutExtension}"
                    } else {
                        "Imported ${result.files.size} NES ROMs from ZIP"
                    }
                    renderLibrary(libraryStore.existingFiles())
                } else {
                    status.text = result.error ?: "That file could not be imported."
                }
            }
        }
    }

    private fun runCiSmokeTest() {
        // Mapper 2 / UxROM with 128 KiB PRG and CHR-RAM. This intentionally mirrors
        // the cartridge class used by the user's supplied test ROM without bundling
        // or redistributing any copyrighted game data.
        val rom = File(filesDir, "ci-mapper2-smoke.nes")
        runCatching { rom.writeBytes(makeCiMapper2Rom()) }
            .onFailure {
                Log.e("NESPocketCI", "Could not create CI ROM", it)
                finish()
                return
            }
        if (!RomFileUtils.isValidNes(rom)) {
            Log.e("NESPocketCI", "Generated CI ROM failed NES validation")
            finish()
            return
        }
        startActivity(Intent(this, EmulationActivity::class.java).apply {
            putExtra(EmulationActivity.EXTRA_ROM_PATH, rom.absolutePath)
            putExtra(EmulationActivity.EXTRA_CI_SMOKE, true)
        })
    }

    private fun makeCiMapper2Rom(): ByteArray {
        val header = byteArrayOf(
            0x4E, 0x45, 0x53, 0x1A, // NES<EOF>
            0x08,                   // eight 16 KiB PRG banks = 128 KiB
            0x00,                   // CHR-RAM
            0x21,                   // mapper 2 + vertical mirroring
            0x00,
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )
        val prg = ByteArray(8 * 16 * 1024) { 0xEA.toByte() }
        val lastBank = 7 * 16 * 1024
        val program = byteArrayOf(
            0x78.toByte(),       // SEI
            0xD8.toByte(),       // CLD
            0x4C, 0x02, 0xC0.toByte() // JMP $C002 forever
        )
        program.copyInto(prg, lastBank)

        // UxROM fixes the last PRG bank at $C000-$FFFF. Point all vectors to $C000.
        val vectorBase = prg.size - 6
        for (i in 0 until 3) {
            prg[vectorBase + i * 2] = 0x00
            prg[vectorBase + i * 2 + 1] = 0xC0.toByte()
        }
        return header + prg
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val EXTRA_CI_SMOKE = "ci_smoke"
    }
}
