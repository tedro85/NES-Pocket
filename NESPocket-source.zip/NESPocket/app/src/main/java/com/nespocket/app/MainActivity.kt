package com.nespocket.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var libraryStore: LibraryStore
    private lateinit var status: TextView
    private lateinit var gamesContainer: LinearLayout
    private var permissionPromptShown = false

    private val readPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) scanLibrary() else renderLibrary(libraryStore.existingFiles())
    }

    private val romPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) importPickedRom(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        libraryStore = LibraryStore(this)
        setContentView(buildUi())
        renderLibrary(libraryStore.existingFiles())
    }

    override fun onResume() {
        super.onResume()
        ensureScanPermissionAndScan()
    }

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi(): ScrollView {
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(14, 14, 16)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(24))
        }
        scroll.addView(root, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

        root.addView(TextView(this).apply {
            text = "NES Pocket"
            textSize = 30f
            setTextColor(Color.WHITE)
        })

        root.addView(TextView(this).apply {
            text = "NES-only emulator • scans for .nes games on launch"
            textSize = 15f
            setTextColor(Color.LTGRAY)
            setPadding(0, dp(4), 0, dp(16))
        })

        status = TextView(this).apply {
            text = "Library ready"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(status)

        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.START
        }
        actionRow.addView(Button(this).apply {
            text = "Rescan"
            setOnClickListener { ensureScanPermissionAndScan(forcePrompt = true) }
        })
        actionRow.addView(Button(this).apply {
            text = "Choose ROM"
            setOnClickListener { romPicker.launch(arrayOf("application/octet-stream", "*/*")) }
        })
        root.addView(actionRow)

        root.addView(TextView(this).apply {
            text = "Games"
            textSize = 21f
            setTextColor(Color.WHITE)
            setPadding(0, dp(20), 0, dp(8))
        })

        gamesContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(gamesContainer)
        return scroll
    }

    private fun ensureScanPermissionAndScan(forcePrompt: Boolean = false) {
        when {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> {
                if (Environment.isExternalStorageManager()) {
                    scanLibrary()
                } else if (forcePrompt || !permissionPromptShown) {
                    permissionPromptShown = true
                    showAllFilesPermissionDialog()
                }
            }
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M -> {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED) {
                    scanLibrary()
                } else {
                    readPermissionLauncher.launch(Manifest.permission.READ_EXTERNAL_STORAGE)
                }
            }
            else -> scanLibrary()
        }
    }

    private fun showAllFilesPermissionDialog() {
        AlertDialog.Builder(this)
            .setTitle("Allow ROM scanning")
            .setMessage("To find .nes files anywhere in your shared storage, NES Pocket needs Android's All files access. If you skip this, you can still use Choose ROM.")
            .setPositiveButton("Open setting") { _, _ ->
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = Uri.parse("package:$packageName")
                }
                runCatching { startActivity(intent) }.onFailure {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            }
            .setNegativeButton("Not now") { _, _ -> renderLibrary(libraryStore.existingFiles()) }
            .show()
    }

    private fun scanLibrary() {
        status.text = "Scanning device for .nes ROMs…"
        executor.execute {
            val previous = libraryStore.loadPaths()
            val result = RomScanner(this).scan()
            val paths = result.files.map { it.absolutePath }.toSet()
            val newCount = (paths - previous).size
            libraryStore.savePaths(paths)
            runOnUiThread {
                status.text = "Found ${result.files.size} NES ROM(s) • $newCount new"
                renderLibrary(result.files)
            }
        }
    }

    private fun renderLibrary(files: List<File>) {
        gamesContainer.removeAllViews()
        if (files.isEmpty()) {
            gamesContainer.addView(TextView(this).apply {
                text = "No .nes ROMs found yet. Put your ROM files on the phone, grant scan access, or tap Choose ROM."
                setTextColor(Color.LTGRAY)
                textSize = 15f
                setPadding(0, dp(8), 0, dp(8))
            })
            return
        }

        files.forEach { file ->
            gamesContainer.addView(Button(this).apply {
                text = file.nameWithoutExtension
                isAllCaps = false
                gravity = Gravity.START or Gravity.CENTER_VERTICAL
                setOnClickListener { launchGame(file) }
            }, ViewGroup.LayoutParams.MATCH_PARENT, dp(56))
        }
    }

    private fun launchGame(file: File) {
        startActivity(Intent(this, EmulationActivity::class.java).apply {
            putExtra(EmulationActivity.EXTRA_ROM_PATH, file.absolutePath)
        })
    }

    private fun importPickedRom(uri: Uri) {
        status.text = "Importing ROM…"
        executor.execute {
            val displayName = queryDisplayName(uri)?.takeIf { it.endsWith(".nes", ignoreCase = true) }
                ?: "imported_${System.currentTimeMillis()}.nes"
            val safeName = displayName.replace(Regex("[^A-Za-z0-9._() -]"), "_")
            val dir = File(filesDir, "imported").apply { mkdirs() }
            val output = File(dir, safeName)

            val success = runCatching {
                contentResolver.openInputStream(uri)?.use { input ->
                    output.outputStream().use { out -> input.copyTo(out) }
                } ?: error("Could not open selected file")
                require(output.length() >= 16) { "ROM file is too small" }
            }.isSuccess

            runOnUiThread {
                if (success) {
                    libraryStore.addPath(output.absolutePath)
                    status.text = "Imported ${output.name}"
                    renderLibrary(libraryStore.existingFiles())
                } else {
                    output.delete()
                    status.text = "That file could not be imported."
                }
            }
        }
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
