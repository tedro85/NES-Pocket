package com.nespocket.app

import android.content.Context
import android.os.Environment
import java.io.File
import java.io.FileOutputStream
import java.util.ArrayDeque
import java.util.zip.ZipFile

class RomScanner(private val context: Context) {

    data class Result(val files: List<File>, val scannedDirectories: Int, val zipArchives: Int)

    fun scan(): Result {
        val roots = buildList {
            @Suppress("DEPRECATION")
            add(Environment.getExternalStorageDirectory())
            add(File(context.filesDir, "imported"))
        }.filter { it.exists() }

        val found = linkedMapOf<String, File>()
        val visited = hashSetOf<String>()
        val queue = ArrayDeque<File>()
        roots.forEach(queue::add)
        var dirs = 0
        var zipArchives = 0

        while (queue.isNotEmpty()) {
            val dir = queue.removeFirst()
            val canonical = runCatching { dir.canonicalPath }.getOrElse { dir.absolutePath }
            if (!visited.add(canonical)) continue
            dirs++

            val children = runCatching { dir.listFiles()?.toList().orEmpty() }.getOrDefault(emptyList())
            for (child in children) {
                if (child.isDirectory) {
                    if (!shouldSkipDirectory(child)) queue.addLast(child)
                } else if (child.isFile) {
                    when {
                        child.extension.equals("nes", ignoreCase = true) && RomFileUtils.isValidNes(child) -> {
                            addFound(found, child)
                        }
                        child.extension.equals("zip", ignoreCase = true) -> {
                            zipArchives++
                            extractNesFromZip(child).forEach { addFound(found, it) }
                        }
                    }
                }
            }
        }

        return Result(
            files = found.values.sortedBy { it.name.lowercase() },
            scannedDirectories = dirs,
            zipArchives = zipArchives
        )
    }

    private fun addFound(found: MutableMap<String, File>, file: File) {
        val key = runCatching { file.canonicalPath }.getOrElse { file.absolutePath }
        found[key] = file
    }

    private fun extractNesFromZip(zipSource: File): List<File> {
        // Avoid recursively re-processing any archive that somehow sits in app-private output.
        if (zipSource.absolutePath.startsWith(context.filesDir.absolutePath)) return emptyList()

        val sourceKey = "${zipSource.absolutePath}|${zipSource.length()}|${zipSource.lastModified()}"
        val archiveDir = File(context.filesDir, "scanned_zips/${RomFileUtils.stableId(sourceKey)}").apply { mkdirs() }
        val marker = File(archiveDir, ".complete")

        if (marker.isFile) {
            return archiveDir.listFiles()
                ?.filter { it.isFile && it.extension.equals("nes", ignoreCase = true) && RomFileUtils.isValidNes(it) }
                .orEmpty()
        }

        archiveDir.listFiles()?.forEach { it.deleteRecursively() }
        val outputs = mutableListOf<File>()

        val success = runCatching {
            ZipFile(zipSource).use { zip ->
                val entries = zip.entries()
                var count = 0
                while (entries.hasMoreElements() && count < MAX_ROMS_PER_ZIP) {
                    val entry = entries.nextElement()
                    if (entry.isDirectory || !entry.name.endsWith(".nes", ignoreCase = true)) continue
                    if (entry.size > MAX_ROM_BYTES) continue

                    val safeName = RomFileUtils.safeFileName(entry.name)
                    val output = uniqueFile(archiveDir, safeName)
                    zip.getInputStream(entry).buffered().use { input ->
                        FileOutputStream(output).buffered().use { out ->
                            copyLimited(input, out, MAX_ROM_BYTES)
                        }
                    }
                    if (RomFileUtils.isValidNes(output)) {
                        outputs += output
                        count++
                    } else {
                        output.delete()
                    }
                }
            }
        }.isSuccess

        if (!success) {
            archiveDir.deleteRecursively()
            return emptyList()
        }

        marker.writeText("ok")
        return outputs
    }


    private fun uniqueFile(dir: File, requestedName: String): File {
        val clean = if (requestedName.endsWith(".nes", ignoreCase = true)) requestedName else "$requestedName.nes"
        var candidate = File(dir, clean)
        if (!candidate.exists()) return candidate
        val base = candidate.nameWithoutExtension
        var index = 2
        while (candidate.exists()) {
            candidate = File(dir, "$base ($index).nes")
            index++
        }
        return candidate
    }

    private fun copyLimited(input: java.io.InputStream, output: java.io.OutputStream, maxBytes: Long) {
        val buffer = ByteArray(DEFAULT_BUFFER_SIZE)
        var total = 0L
        while (true) {
            val read = input.read(buffer)
            if (read < 0) break
            total += read
            require(total <= maxBytes) { "NES file in ZIP is unexpectedly large" }
            output.write(buffer, 0, read)
        }
    }

    private fun shouldSkipDirectory(file: File): Boolean {
        val path = file.absolutePath.replace('\\', '/').lowercase()
        return path.contains("/android/data/") ||
            path.contains("/android/obb/") ||
            path.endsWith("/android/data") ||
            path.endsWith("/android/obb") ||
            path.startsWith(context.cacheDir.absolutePath.lowercase())
    }

    companion object {
        private const val MAX_ROMS_PER_ZIP = 20
        private const val MAX_ROM_BYTES = 32L * 1024L * 1024L
    }
}
