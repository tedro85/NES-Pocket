package com.nespocket.app

import android.content.Context
import android.os.Environment
import java.io.File
import java.util.ArrayDeque

class RomScanner(private val context: Context) {

    data class Result(val files: List<File>, val scannedDirectories: Int)

    fun scan(): Result {
        val roots = buildList {
            @Suppress("DEPRECATION")
            add(Environment.getExternalStorageDirectory())
            add(File(context.filesDir, "imported"))
        }.filter { it.exists() }

        val found = linkedMapOf<String, File>()
        val visited = hashSetOf<String>()
        val queue = ArrayDeque<File>()
        roots.forEach(queue::add)
        var dirs = 0

        while (queue.isNotEmpty()) {
            val dir = queue.removeFirst()
            val canonical = runCatching { dir.canonicalPath }.getOrElse { dir.absolutePath }
            if (!visited.add(canonical)) continue
            dirs++

            val children = runCatching { dir.listFiles()?.toList().orEmpty() }.getOrDefault(emptyList())
            for (child in children) {
                if (child.isDirectory) {
                    if (!shouldSkipDirectory(child)) queue.addLast(child)
                } else if (child.isFile && child.extension.equals("nes", ignoreCase = true)) {
                    val key = runCatching { child.canonicalPath }.getOrElse { child.absolutePath }
                    found[key] = child
                }
            }
        }

        return Result(
            files = found.values.sortedBy { it.name.lowercase() },
            scannedDirectories = dirs
        )
    }

    private fun shouldSkipDirectory(file: File): Boolean {
        val path = file.absolutePath.replace('\\', '/').lowercase()
        return path.contains("/android/data/") ||
            path.contains("/android/obb/") ||
            path.endsWith("/android/data") ||
            path.endsWith("/android/obb")
    }
}
