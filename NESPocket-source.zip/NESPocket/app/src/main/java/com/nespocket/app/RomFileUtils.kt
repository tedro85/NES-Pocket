package com.nespocket.app

import java.io.File
import java.security.MessageDigest

object RomFileUtils {
    private val inesMagic = byteArrayOf('N'.code.toByte(), 'E'.code.toByte(), 'S'.code.toByte(), 0x1A)

    fun isValidNes(file: File): Boolean {
        if (!file.isFile || file.length() < 16) return false
        return runCatching {
            file.inputStream().buffered().use { input ->
                val header = ByteArray(4)
                input.read(header) == 4 && header.contentEquals(inesMagic)
            }
        }.getOrDefault(false)
    }

    fun safeFileName(name: String): String = name
        .substringAfterLast('/')
        .substringAfterLast('\\')
        .replace(Regex("[^A-Za-z0-9._() \\[\\]-]"), "_")
        .take(180)
        .ifBlank { "game.nes" }

    fun stableId(value: String): String {
        val digest = MessageDigest.getInstance("SHA-1").digest(value.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }.take(20)
    }
}
