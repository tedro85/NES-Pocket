package com.nespocket.app

import android.content.Context
import android.content.Intent
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class EmulationSmokeTest {
    @Test
    fun generatedNesRomLoadsAndRendersFrames() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val rom = File(context.filesDir, "ci-smoke-test.nes")
        rom.writeBytes(makeMinimalNesRom())

        assertTrue("Generated smoke-test ROM must pass NES validation", RomFileUtils.isValidNes(rom))

        val intent = Intent(context, EmulationActivity::class.java).apply {
            putExtra(EmulationActivity.EXTRA_ROM_PATH, rom.absolutePath)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        ActivityScenario.launch<EmulationActivity>(intent).use { scenario ->
            val deadline = System.currentTimeMillis() + 10_000L
            var frameSeen = false
            while (System.currentTimeMillis() < deadline && !frameSeen) {
                scenario.onActivity { activity ->
                    assertFalse("Emulation activity unexpectedly finished", activity.isFinishing)
                    frameSeen = activity.firstFrameRendered
                }
                if (!frameSeen) Thread.sleep(250)
            }
            assertTrue("NES core never rendered a frame within 10 seconds", frameSeen)
        }
    }

    private fun makeMinimalNesRom(): ByteArray {
        val header = byteArrayOf(
            0x4E, 0x45, 0x53, 0x1A, // NES<EOF>
            0x01, // one 16 KiB PRG bank
            0x01, // one 8 KiB CHR bank
            0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
        )
        val prg = ByteArray(16 * 1024) { 0xEA.toByte() } // NOP-filled NROM-128
        val program = byteArrayOf(
            0x78.toByte(),             // SEI
            0xD8.toByte(),             // CLD
            0xA2.toByte(), 0x40,       // LDX #$40
            0x8E.toByte(), 0x17, 0x40, // STX $4017
            0xA2.toByte(), 0xFF.toByte(), // LDX #$FF
            0x9A.toByte(),             // TXS
            0xE8.toByte(),             // INX -> 0
            0x8E.toByte(), 0x00, 0x20, // STX $2000
            0x8E.toByte(), 0x01, 0x20, // STX $2001
            0x8E.toByte(), 0x10, 0x40, // STX $4010
            0x4C, 0x14, 0x80.toByte()  // JMP $8014
        )
        program.copyInto(prg, 0)

        // NMI, RESET, IRQ vectors all point to $8000. For a 16 KiB PRG bank this
        // bank is mirrored into $C000-$FFFF, so vectors live at the end of this bank.
        prg[0x3FFA] = 0x00
        prg[0x3FFB] = 0x80.toByte()
        prg[0x3FFC] = 0x00
        prg[0x3FFD] = 0x80.toByte()
        prg[0x3FFE] = 0x00
        prg[0x3FFF] = 0x80.toByte()

        val chr = ByteArray(8 * 1024)
        return header + prg + chr
    }
}
