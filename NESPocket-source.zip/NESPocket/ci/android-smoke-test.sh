#!/usr/bin/env bash
set -Eeuo pipefail

REPORT_DIR="$PWD/build/reports/ci-android"
mkdir -p "$REPORT_DIR"

if [[ "${GITHUB_ACTIONS:-}" != "true" ]]; then
  echo "Not running under GitHub Actions; skipping virtual Android smoke test."
  exit 0
fi

export ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}}"
export ANDROID_HOME="$ANDROID_SDK_ROOT"
export PATH="$ANDROID_SDK_ROOT/platform-tools:$ANDROID_SDK_ROOT/emulator:$ANDROID_SDK_ROOT/cmdline-tools/latest/bin:$PATH"

cleanup() {
  set +e
  adb logcat -d -v threadtime > "$REPORT_DIR/logcat.txt" 2>&1
  adb exec-out screencap -p > "$REPORT_DIR/screenshot.png" 2>/dev/null
  adb shell dumpsys activity activities > "$REPORT_DIR/activity.txt" 2>&1
  adb shell dumpsys package com.nespocket.app > "$REPORT_DIR/package.txt" 2>&1
  adb emu kill >/dev/null 2>&1
  if [[ -n "${EMU_PID:-}" ]]; then kill "$EMU_PID" >/dev/null 2>&1; fi
}
trap cleanup EXIT

echo "=== NES Pocket virtual Android smoke test ==="
echo "SDK: $ANDROID_SDK_ROOT"

if [[ -e /dev/kvm ]]; then
  sudo chmod 666 /dev/kvm || true
fi

yes | sdkmanager --licenses >/dev/null 2>&1 || true
sdkmanager --install \
  "platform-tools" \
  "emulator" \
  "system-images;android-35;google_apis;x86_64"

AVD_NAME="nes-pocket-ci-api35"
echo "no" | avdmanager create avd --force \
  --name "$AVD_NAME" \
  --package "system-images;android-35;google_apis;x86_64" \
  --device "pixel_6"

EMU_ARGS=(
  -avd "$AVD_NAME"
  -no-window
  -no-audio
  -no-boot-anim
  -no-snapshot
  -wipe-data
  -gpu swiftshader_indirect
  -camera-back none
  -camera-front none
  -memory 2048
)

emulator "${EMU_ARGS[@]}" > "$REPORT_DIR/emulator.txt" 2>&1 &
EMU_PID=$!

adb wait-for-device

echo "Waiting for Android to finish booting..."
BOOT_DEADLINE=$((SECONDS + 300))
until [[ "$(adb shell getprop sys.boot_completed 2>/dev/null | tr -d '\r')" == "1" ]]; do
  if (( SECONDS >= BOOT_DEADLINE )); then
    echo "ERROR: Android emulator did not finish booting within 5 minutes."
    exit 31
  fi
  if ! kill -0 "$EMU_PID" 2>/dev/null; then
    echo "ERROR: Android emulator process exited during boot."
    tail -n 120 "$REPORT_DIR/emulator.txt" || true
    exit 32
  fi
  sleep 2
done

adb shell settings put global window_animation_scale 0
adb shell settings put global transition_animation_scale 0
adb shell settings put global animator_duration_scale 0

APK="$PWD/app/build/outputs/apk/debug/app-debug.apk"
if [[ ! -f "$APK" ]]; then
  echo "ERROR: APK not found at $APK"
  exit 33
fi

# Verify the x86_64 Nestopia core is physically packaged in the APK before launch.
if ! unzip -l "$APK" | grep -q 'lib/x86_64/libnestopia_libretro_android.so'; then
  echo "ERROR: x86_64 Nestopia core is missing from APK."
  unzip -l "$APK" | grep -E 'lib/.+\.so' || true
  exit 34
fi

echo "Installing APK onto virtual Android device..."
adb install -r "$APK"
adb logcat -c

# MainActivity's CI mode creates a tiny mapper-2/UxROM ROM (the same mapper class
# as the user's test ROM), launches EmulationActivity, and logs CI_SMOKE_OK after
# LibretroDroid reports the first rendered frame.
adb shell am force-stop com.nespocket.app
adb shell am start -W \
  -n com.nespocket.app/.MainActivity \
  --ez ci_smoke true

TEST_DEADLINE=$((SECONDS + 30))
while (( SECONDS < TEST_DEADLINE )); do
  LOGS="$(adb logcat -d -v brief 2>/dev/null || true)"
  if grep -q 'CI_SMOKE_OK' <<<"$LOGS"; then
    echo "PASS: virtual Android rendered an NES frame."
    exit 0
  fi
  if grep -Eq 'FATAL EXCEPTION|Fatal signal|libc.*Fatal|DEBUG.*backtrace' <<<"$LOGS"; then
    echo "ERROR: app crashed while loading the CI NES ROM."
    grep -E -A40 -B10 'FATAL EXCEPTION|Fatal signal|libc.*Fatal|DEBUG.*backtrace' <<<"$LOGS" | tail -n 180 || true
    exit 35
  fi
  if ! adb shell pidof com.nespocket.app >/dev/null 2>&1; then
    echo "ERROR: NES Pocket process exited before rendering a frame."
    exit 36
  fi
  sleep 1
done

echo "ERROR: NES Pocket stayed open but no NES frame was rendered within 30 seconds."
exit 37
